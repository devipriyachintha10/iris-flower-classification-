"""
Iris Flower Classification
---------------------------
A machine learning model that predicts the species of an iris flower
(Setosa, Versicolor, or Virginica) based on sepal and petal measurements.

Author: Devipriya Chintha
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# -----------------------------
# 1. Load the dataset
# -----------------------------
iris = load_iris()
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df["species"] = pd.Categorical.from_codes(iris.target, iris.target_names)

print("First 5 rows of the dataset:")
print(df.head())
print("\nDataset shape:", df.shape)
print("\nClass distribution:\n", df["species"].value_counts())

# -----------------------------
# 2. Exploratory Data Analysis
# -----------------------------
sns.pairplot(df, hue="species", corner=True)
plt.suptitle("Iris Dataset - Feature Relationships by Species", y=1.02)
plt.savefig("pairplot.png", dpi=150, bbox_inches="tight")
plt.close()

plt.figure(figsize=(6, 4))
sns.heatmap(df.drop(columns="species").corr(), annot=True, cmap="Blues")
plt.title("Feature Correlation Heatmap")
plt.tight_layout()
plt.savefig("correlation_heatmap.png", dpi=150)
plt.close()

print("\nSaved visualizations: pairplot.png, correlation_heatmap.png")

# -----------------------------
# 3. Prepare data for modeling
# -----------------------------
X = df.drop(columns="species")
y = df["species"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# -----------------------------
# 4. Train the model
# -----------------------------
model = KNeighborsClassifier(n_neighbors=5)
model.fit(X_train_scaled, y_train)

# -----------------------------
# 5. Evaluate the model
# -----------------------------
y_pred = model.predict(X_test_scaled)
accuracy = accuracy_score(y_test, y_pred)

print(f"\nModel Accuracy: {accuracy * 100:.2f}%")
print("\nClassification Report:\n", classification_report(y_test, y_pred))

cm = confusion_matrix(y_test, y_pred, labels=iris.target_names)
plt.figure(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Greens",
            xticklabels=iris.target_names, yticklabels=iris.target_names)
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")
plt.tight_layout()
plt.savefig("confusion_matrix.png", dpi=150)
plt.close()

print("Saved confusion_matrix.png")

# -----------------------------
# 6. Predict on a new sample
# -----------------------------
sample = pd.DataFrame(
    [[5.1, 3.5, 1.4, 0.2]],
    columns=iris.feature_names
)
sample_scaled = scaler.transform(sample)
prediction = model.predict(sample_scaled)
print(f"\nPrediction for sample {sample.values.tolist()}: {prediction[0]}")
